<?php include 'header.php' ?>

    <main class="main">
        <section class="section hero">

            <div class="owl-carousel owl-theme hero__slider">

                <div class="item">
                    <div class="hero__slider-box">
                        <div class="container">
    
                            <h1 class="h hero__title">Проектирование<br> и строительство в лице<br> одной организации</h1>
                            <div class="hero__subtitle">
                                Полный комплекс проектных, строительных, монтажных и ремонтных работ объектов различного
                                целевого назначения.
                            </div>
                            <div class="hero__address-box">
                                <div class="hero__name">Илим</div>
                                <div class="hero__address">ул. Ленини д.116</div>
                                <a href="#" class="hero__desc">Проектирование</a>
                                <a href="#" S class="hero__desc">реконструкция</a>
                            </div>
                            <a href="ilim.php" class="btn btn-white btn-hero">Подробнее о проекте<img src="img/arrow-down.png" alt=""></a>
                            <div class="hero__box-nav">
                            </div>
                            
                        </div>
                        
                    </div>
                </div>

                <div class="item">
                    <div class="hero__slider-box">
                        <div class="container">
    
                            <h1 class="h hero__title">Проектирование<br> индивидуальность</h1>
                            <div class="hero__subtitle">
                                Полный комплекс проектных, строительных, монтажных и ремонтных работ объектов различного
                                целевого назначения.
                            </div>
                            <div class="hero__address-box">
                                <div class="hero__name">Илим</div>
                                <div class="hero__address">ул. Ленини д.116</div>
                                <a href="#" class="hero__desc">Проектирование</a>
                                <a href="#" S class="hero__desc">реконструкция</a>
                            </div>
                            <a href="ilim.php" class="btn btn-white btn-hero">Подробнее о проекте<img src="img/arrow-down.png" alt=""></a>
                            <div class="hero__box-nav">
                            </div>
                            
                        </div>
                        
                    </div>
                </div>

                <div class="item">
                    <div class="hero__slider-box">
                        <div class="container">
    
                            <h1 class="h hero__title">Проектирование<br> и строительство в лице<br> одной организации</h1>
                            <div class="hero__subtitle">
                                Полный комплекс проектных, строительных, монтажных и ремонтных работ объектов различного
                                целевого назначения.
                            </div>
                            <div class="hero__address-box">
                                <div class="hero__name">Илим</div>
                                <div class="hero__address">ул. Ленини д.116</div>
                                <a href="#" class="hero__desc">Проектирование</a>
                                <a href="#" S class="hero__desc">реконструкция</a>
                            </div>
                            <a href="ilim.php" class="btn btn-white btn-hero">Подробнее о проекте<img src="img/arrow-down.png" alt=""></a>
                            <div class="hero__box-nav">
                            </div>
                            
                        </div>
                        
                    </div>
                </div>

                <div class="item">
                    <div class="hero__slider-box">
                        <div class="container">
    
                            <h1 class="h hero__title">Проектирование<br> и строительство в лице<br> одной организации</h1>
                            <div class="hero__subtitle">
                                Полный комплекс проектных, строительных, монтажных и ремонтных работ объектов различного
                                целевого назначения.
                            </div>
                            <div class="hero__address-box">
                                <div class="hero__name">Илим</div>
                                <div class="hero__address">ул. Ленини д.116</div>
                                <a href="#" class="hero__desc">Проектирование</a>
                                <a href="#" S class="hero__desc">реконструкция</a>
                            </div>
                            <a href="ilim.php" class="btn btn-white btn-hero">Подробнее о проекте<img src="img/arrow-down.png" alt=""></a>
                            <div class="hero__box-nav">
                            </div>
                            
                        </div>
                        
                    </div>
                </div>

                <div class="item">
                    <div class="hero__slider-box">
                        <div class="container">
    
                            <h1 class="h hero__title">Проектирование<br> и строительство в лице<br> одной организации</h1>
                            <div class="hero__subtitle">
                                Полный комплекс проектных, строительных, монтажных и ремонтных работ объектов различного
                                целевого назначения.
                            </div>
                            <div class="hero__address-box">
                                <div class="hero__name">Илим</div>
                                <div class="hero__address">ул. Ленини д.116</div>
                                <a href="#" class="hero__desc">Проектирование</a>
                                <a href="#" S class="hero__desc">реконструкция</a>
                            </div>
                            <a href="ilim.php" class="btn btn-white btn-hero">Подробнее о проекте<img src="img/arrow-down.png" alt=""></a>
                            <div class="hero__box-nav">
                            </div>
                            
                        </div>
                        
                    </div>
                </div>

                
            </div>

            <button class="arrow arrow-next"><img src="img/arrow-big.png" alt=""></button>

        </section>
        <!-- /.section hero -->

        <div class="cart-box">
            <div class="cart__box cart__box_1">
                <div class="cart__box-title">Проектирование</div>
                <div class="cart__box-desc">Разработка эскизного проекта, проектной и рабочей документации,
                    проектов интерьера помещений и ландшафтного дизайна.</div>
            </div>
            <div class="cart__box cart__box_2">
                <div class="cart__box-title">Строительство</div>
                <div class="cart__box-desc">Капитальное строительство "под ключ". Реконструкция и ремонт зданий и сооружений. Реставрация объектов недвижимости и возвращение утраченного или искажённого исторического облика.</div>
            </div>
            <div class="cart__box cart__box_3">
                <div class="cart__box-title">Инженерные системы</div>
                <div class="cart__box-desc"><p class="cart__p">
                    Обустройство и обслуживание инженерных систем. Теплоснабжение. Водоснабжение и канализация. Наружное освещение
                </p>
                    <p>
                        Электропотребление. Вентиляция и кондиционирование. Сигнализация и связь. Пожаротушениние.
                    </p></div>
            </div>
        </div>
        <!-- /.cart-box -->

        <section class="section analysis">
            <div class="container">
                <div class="analysis__wrap">
                    <a href="#" class="btn analysis__project-link">проектирование</a>
                    <h2 class="h2 section__title">Скрупулёзный анализ и&nbsp;внимание к деталям</h2>
                    <p class="p1 analysis__desc">Архитектурное и рабочее проектирование для объектов капитального строительства, реконструкции и ремонта.</p>
                    <ul class="analysis__list">
                        <li class="analysis__item "><a href="#" class="analysis__list-link">Эскизные проекты</a></li>
                        <li class="analysis__item"><a href="#" class="analysis__list-link">Проектная документация</a></li>
                        <li class="analysis__item"><a href="#" class="analysis__list-link">Интерьерный дизайн</a></li>
                        <li class="analysis__item"><a href="#" class="analysis__list-link">Ландшафтный дизайн</a></li>
                    </ul>
                    <button class="btn btn-callback ">О проектировании</button>
                </div>
            </div>
        </section>
        <!-- /.section analysis -->

        <section class="section experions">
            <div class="experions__wrap">
                <div class="container">
                    <div class="experions__box">
                        <h3 class="h3 section__title">Более 20 лет опыта и&nbsp;большой гарант доверия</h3>
                        <p class="p2 experions__desc">Мы имеем богатый опыт работы, достаточную материально- техническую базу и квалифицированный персонал, более 30 человек с опытом работы свыше 10 лет.</p>
                        <a href="#" class="experions__link">Подробнее о строительстве</a>
                </div>
            </div>
        </section>
        <!-- /.section experions -->

        <section class="section system">
            
            <h2 class="h2 system__title">Инженерные системы</h2>
            <div class="p1 system__desc">Независимо от целевого назначения современные здания плотно заполняются инженерными сетями, необходимыми для комфортного нахождения людей и правильной работы оборудования.</div>
            <div class="system__wrap">

                <div class="system__cart-box">
                    <div class="system__cart">
                        <div class="system__cart-icon">
                            <img src="img/system-cart-1.png" alt="">
                        </div>
                        <div class="system__cart-info">
                            <h4 class="h4 system__cart-title">Теплоснабжение</h4>
                            <div class="p2 system__cart-desc">Подача тепла для жилых, общественных и промышленных зданий для обеспечения коммунально-бытовых и технологических нужд потребителей.</div>
                            <a href="#" class="system__cart-link">подробнее</a>
                        </div>
                    </div>

                    <div class="system__cart">
                        <div class="system__cart-icon">
                            <img src="img/system-cart-2.png" alt="">
                        </div>
                        <div class="system__cart-info">
                            <h4 class="h4 system__cart-title">Водоснабжение и канализация</h4>
                            <div class="p2 system__cart-desc">Комплекс инженерных сооружений и устройств для получения воды потребителями и отвода сточных вод до точки сброса</div>
                            <a href="#" class="system__cart-link">подробнее</a>
                        </div>
                    </div>

                    <div class="system__cart">
                        <div class="system__cart-icon">
                            <img src="img/system-cart-3.png" alt="">
                        </div>
                        <div class="system__cart-info">
                            <h4 class="h4 system__cart-title">Наружное освещение</h4>
                            <div class="p2 system__cart-desc">Средства искусственного увеличения оптической видимости на улице в тёмное время суток и архитектурная подсветка</div>
                            <a href="#" class="system__cart-link">подробнее</a>
                        </div>
                    </div>

                    <div class="system__cart">
                        <div class="system__cart-icon">
                            <img src="img/system-cart-4.png" alt="">
                        </div>
                        <div class="system__cart-info">
                            <h4 class="h4 system__cart-title">Пожаротушениние</h4>
                            <div class="p2 system__cart-desc">Стационарные системы тушения, предназначенные для устранения или локализации пожара, путем выпуска специальных огнетушащих веществ.</div>
                            <a href="#" class="system__cart-link">подробнее</a>
                        </div>
                    </div>
                </div>

                <div class="system__cart-box">
                    
                    <div class="system__cart">
                        <div class="system__cart-icon">
                            <img src="img/system-cart-5.png" alt="">
                        </div>
                        <div class="system__cart-info">
                            <h4 class="h4 system__cart-title">Электропотребление</h4>
                            <div class="p2 system__cart-desc">Совокупность технологических установок и устройств, имеющих в своем составе электроприемники, и предназначенных для передачи и распределения электроэнергии с целью ее преобразования в другие виды.</div>
                            <a href="#" class="system__cart-link">подробнее</a>
                        </div>
                    </div>
                    
                    
                    <div class="system__cart">
                        <div class="system__cart-icon">
                            <img src="img/system-cart-6.png" alt="">
                        </div>
                        <div class="system__cart-info">
                            <h4 class="h4 system__cart-title">Вентиляция</h4>
                            <div class="p2 system__cart-desc">Процесс удаления отработанного воздуха из помещения и замена его наружным.</div>
                            <a href="#" class="system__cart-link">подробнее</a>
                        </div>
                    </div>
                    
                    <div class="system__cart">
                        <div class="system__cart-icon">
                            <img src="img/system-cart-7.png" alt="">
                        </div>
                        <div class="system__cart-info">
                            <h4 class="h4 system__cart-title">Сигнализация и связь</h4>
                            <div class="p2 system__cart-desc">Световое и звуковое оповещение об аварийных ситуациях в различных системах оповещения в помещениях и снаружи.</div>
                            <a href="#" class="system__cart-link">подробнее</a>
                        </div>
                    </div>
                </div>


            </div>

        </section>
        <!-- /.section system -->

        <section class="section  features">
            <div class="container">
                <h2 class="h2 features__title">Ценности Вяттехинвестстрой - это технологичность, традиции, надежность и индивидуальность.</h2>
                <div class="features__wrap">

                    <div class="features__box">

                        <div class="features__cart">
                            <div class="features__cart-icon">
                                <img src="img/features-1.png" alt="">
                            </div>
                            <div class="features__cart-desc">
                                <div class="h5 features__cart-title">Опыт работы</div>
                                <div class="p1 features__cart-text">Опыт работы на рынке строительства более 20 лет</div>
                            </div>
                        </div>

                        <div class="features__cart">
                            <div class="features__cart-icon">
                                <img src="img/features-2.png" alt="">
                            </div>
                            <div class="features__cart-desc">
                                <div class="h5 features__cart-title">Качество</div>
                                <div class="p1 features__cart-text">Качество, оперативность и широкий спектр предлагаемых
                                    услуг</div>
                            </div>
                        </div>

                        <div class="features__cart">
                            <div class="features__cart-icon">
                                <img src="img/features-3.png" alt="">
                            </div>
                            <div class="features__cart-desc">
                                <div class="h5 features__cart-title">Ответственность</div>
                                <div class="p1 features__cart-text">Максимальная ответственность за результаты проекта</div>
                            </div>
                        </div>

                    </div>

                    <div class="features__box">

                        <div class="features__cart">
                            <div class="features__cart-icon">
                                <img src="img/features-4.png" alt="">
                            </div>
                            <div class="features__cart-desc">
                                <div class="h5 features__cart-title">Собственное бюро</div>
                                <div class="p1 features__cart-text">Собственное архитектурное, проектное и конструкторское
                                    Бюро</div>
                            </div>
                        </div>

                        <div class="features__cart">
                            <div class="features__cart-icon">
                                <img src="img/features-5.png" alt="">
                            </div>
                            <div class="features__cart-desc">
                                <div class="h5 features__cart-title">Функции генподрядчика</div>
                                <div class="p1 features__cart-text">Функции генподрядчика - «все в одних руках»</div>
                            </div>
                        </div>


                    </div>

                </div>
            </div>
        </section>
        <!-- /.section  features -->

        <section class="section project">
            <h2 class="h2 project__title">Выполненные проекты и&nbsp;довольные клиенты</h2>
            <div class="p1 project__desc">С 1999 года мы спроектировали и реализовали в жизнь десятки объектов различной сложности и направленности. Посмотрите примеры наших работ и обращайтесь с собственными задачами!</div>

            <div class="container">
                <div class="project__clients-box">
                    <div class="project__clients-cart"></div>
                    <div class="project__clients-cart"></div>
                    <div class="project__clients-cart"></div>
                    <div class="project__clients-cart"></div>
                    <div class="project__clients-cart"></div>
                </div>
                <div class="project__example-box">
                    <div class="project__example">
                        <a href="#"><img src="img/project1.jpg" alt=""></a>
                    </div>
                    <div class="project__example">
                        <a href="#"><img src="img/project2.jpg" alt=""></a>
                    </div>
                    <div class="project__example">
                        <a href="#"><img src="img/project3.jpg" alt=""></a>
                    </div>
                    <div class="project__example">
                        <a href="#"><img src="img/project4.jpg" alt=""></a>
                    </div>
                    <div class="project__example">
                        <a href="#"><img src="img/project5.jpg" alt=""></a>
                    </div>
                    <div class="project__example">
                        <a href="#"><img src="img/project6.jpg" alt=""></a>
                    </div>
                    <div class="project__example">
                        <a href="#"><img src="img/project7.jpg" alt=""></a>
                    </div>
                    <div class="project__example">
                        <a href="#"><img src="img/project8.jpg" alt=""></a>
                    </div>
                </div>
                <div class="project__btn-box">
                    <button class="btn btn-callback ">Полный каталлог проектов</button>
                </div>
            </div>
        </section>
        <!-- /.section project -->

        <section class="section feedback">
            <div class="container">
                <h2 class="h2 feedback__title">Есть проект?<br>Давайте обсудим.</h2>
                <div class="p1 feedback__text">Оставьте номер телефона и наш проектный менеджер перезвонит вам в близжайшие 5&nbsp;минут. </div>
                <form action="#" class="feedback__form">
                    <input class="feedback__form-input" type="tel" name="phone" required placeholder="+7">
                    <button type="submit" class="btn feedback__form-btn" plac>Обратный звонок</button>
                </form>
            </div>
        </section>
        <!-- /.section feedback -->

    </main>
    <!-- /.main -->

    <?php include 'footer.php'; ?>