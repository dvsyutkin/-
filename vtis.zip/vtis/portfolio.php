<?php include 'header.php'; ?>
    <main class="main">
        <div class="container">
            <h1 class="h hero__title hero-ilim__title portfolio__title">Портфолио</h1>
            <div class="p1 portfolio__desc">Молодом эко-поселке «Васильковые поля» на живописном участке располагается современный двухэтажный коттедж.</div>
        </div>
        <!-- /.container -->

        <div class="portfolio-wrap">

            <div class="portfolio__box portfolio__box_1">
                <div class="portfolio__box-title">Илим</div>
                <div class="p1 portfolio__box-text">Молодом эко-поселке «Васильковые поля» на живописном участке располагается современный двухэтажный коттедж.</div>
                <div class="portfolio__address">
                    <div class="portfolio__address-box_1">
                        <div class="h4 portfolio__address-title">Адрeс</div>
                        <div class="p1 portfolio__address-text">ул. Ленини д.116</div>
                    </div>
                    <div class="portfolio__address-box_2">
                        <div class="h4  portfolio__address-title">Общая площадь:</div>
                        <div class="p1 portfolio__address-text">301 м2</div>
                    </div>
                </div>
                <a href="ilim.php" class="btn btn-white btn-hero btn-portfolio">Подробнее о проекте</a>
            </div>

            <div class="portfolio__box portfolio__box_1">
                <div class="portfolio__box-title">Васильковые поля</div>
                <div class="p1 portfolio__box-text">Молодом эко-поселке «Васильковые поля» на живописном участке располагается современный двухэтажный коттедж.</div>
                <div class="portfolio__address">
                    <div class="portfolio__address-box_1">
                        <div class="h4 portfolio__address-title">Адрeс</div>
                        <div class="p1 portfolio__address-text">ул. Ленини д.116</div>
                    </div>
                    <div class="portfolio__address-box_2">
                        <div class="h4  portfolio__address-title">Общая площадь:</div>
                        <div class="p1 portfolio__address-text">301 м2</div>
                    </div>
                </div>
                <a href="ilim.php" class="btn btn-white btn-hero btn-portfolio">Подробнее о проекте</a>
            </div>

            <div class="portfolio__box portfolio__box_1">
                <div class="portfolio__box-title">Илим</div>
                <div class="p1 portfolio__box-text">Молодом эко-поселке «Васильковые поля» на живописном участке располагается современный двухэтажный коттедж.</div>
                <div class="portfolio__address">
                    <div class="portfolio__address-box_1">
                        <div class="h4 portfolio__address-title">Адрeс</div>
                        <div class="p1 portfolio__address-text">ул. Ленини д.116</div>
                    </div>
                    <div class="portfolio__address-box_2">
                        <div class="h4  portfolio__address-title">Общая площадь:</div>
                        <div class="p1 portfolio__address-text">301 м2</div>
                    </div>
                </div>
                <a href="ilim.php" class="btn btn-white btn-hero btn-portfolio">Подробнее о проекте</a>
            </div>

            <div class="portfolio__box portfolio__box_1">
                <div class="portfolio__box-title">Васильковые поля</div>
                <div class="p1 portfolio__box-text">Молодом эко-поселке «Васильковые поля» на живописном участке располагается современный двухэтажный коттедж.</div>
                <div class="portfolio__address">
                    <div class="portfolio__address-box_1">
                        <div class="h4 portfolio__address-title">Адрeс</div>
                        <div class="p1 portfolio__address-text">ул. Ленини д.116</div>
                    </div>
                    <div class="portfolio__address-box_2">
                        <div class="h4  portfolio__address-title">Общая площадь:</div>
                        <div class="p1 portfolio__address-text">301 м2</div>
                    </div>
                </div>
                <a href="ilim.php" class="btn btn-white btn-hero btn-portfolio">Подробнее о проекте</a>
            </div>

            <div class="portfolio__box portfolio__box_1">
                <div class="portfolio__box-title">Илим</div>
                <div class="p1 portfolio__box-text">Молодом эко-поселке «Васильковые поля» на живописном участке располагается современный двухэтажный коттедж.</div>
                <div class="portfolio__address">
                    <div class="portfolio__address-box_1">
                        <div class="h4 portfolio__address-title">Адрeс</div>
                        <div class="p1 portfolio__address-text">ул. Ленини д.116</div>
                    </div>
                    <div class="portfolio__address-box_2">
                        <div class="h4  portfolio__address-title">Общая площадь:</div>
                        <div class="p1 portfolio__address-text">301 м2</div>
                    </div>
                </div>
                <a href="ilim.php" class="btn btn-white btn-hero btn-portfolio">Подробнее о проекте</a>
            </div>

            <div class="portfolio__box portfolio__box_1">
                <div class="portfolio__box-title">Васильковые поля</div>
                <div class="p1 portfolio__box-text">Молодом эко-поселке «Васильковые поля» на живописном участке располагается современный двухэтажный коттедж.</div>
                <div class="portfolio__address">
                    <div class="portfolio__address-box_1">
                        <div class="h4 portfolio__address-title">Адрeс</div>
                        <div class="p1 portfolio__address-text">ул. Ленини д.116</div>
                    </div>
                    <div class="portfolio__address-box_2">
                        <div class="h4  portfolio__address-title">Общая площадь:</div>
                        <div class="p1 portfolio__address-text">301 м2</div>
                    </div>
                </div>
                <a href="ilim.php" class="btn btn-white btn-hero btn-portfolio">Подробнее о проекте</a>
            </div>


            
        </div>

    </main>
    <!-- /.main -->


<?php include 'footer.php'; ?>