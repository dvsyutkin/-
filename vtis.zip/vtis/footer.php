<footer class="footer">
    <div class="container">

        <div class="footer__contacts-box">
            <div class="footer__logo-box"><img src="img/logo.png" alt=""></div>
            <div class="footer__relation">
                <div class="footer__relation-box footer__relation-box_1">
                    <div class="p2 footer__relation-title">Электронная почта</div>
                    <a class="h3 footer__relation-link" href="mailto:sale@vtis-kirov.ru">sale@vtis-kirov.ru</a>
                </div>
                <div class="footer__relation-box">
                    <div class="p2 footer__relation-title">Кониактный телефон</div>
                    <a class="h3 footer__relation-link" href="tel:+78332628383">+7 8332 62-83-83</a>
                </div>
            </div>
        </div>

        <div class="footer__nav-wrap">

            <div class="footer__nav-box">
                <div class="h5 footer__nav-title">Проектирование</div>
                <ul class="footer__list footer__project">
                    <li class="footer__item"><a href="#" class="p2 footer__list-link">Эскизные проекты</a></li>
                    <li class="footer__item"><a href="#" class="p2 footer__list-link">Проектная документация</a></li>
                    <li class="footer__item"><a href="#" class="p2 footer__list-link">Интерьерный дизайн</a></li>
                    <li class="footer__item"><a href="#" class="p2 footer__list-link">Ландшафтный дизайн</a></li>
                </ul>
            </div>

            <div class="footer__nav-box">
                <div class="h5 footer__nav-title">Строительство</div>
                <ul class="footer__list footer__project">
                    <li class="footer__item"><a href="#" class="p2 footer__list-link">Капитальное строительство</a></li>
                    <li class="footer__item"><a href="#" class="p2 footer__list-link">Реконструкция и ремонт</a></li>
                    <li class="footer__item"><a href="#" class="p2 footer__list-link">Реставрация</a></li>
                </ul>
            </div>

            <div class="footer__nav-box">
                <div class="h5 footer__nav-title">инженерные системы</div>
                <ul class="footer__list footer__project">
                    <li class="footer__item"><a href="#" class="p2 footer__list-link">Теплоснабжение</a></li>
                    <li class="footer__item"><a href="#" class="p2 footer__list-link">Водоснабжение и канализация</a>
                    </li>
                    <li class="footer__item"><a href="#" class="p2 footer__list-link">Наружное освещение</a></li>
                    <li class="footer__item"><a href="#" class="p2 footer__list-link">Электропотребление</a></li>
                    <li class="footer__item"><a href="#" class="p2 footer__list-link">Вентиляция</a></li>
                    <li class="footer__item"><a href="#" class="p2 footer__list-link">Сигнализация и связь</a></li>
                    <li class="footer__item"><a href="#" class="p2 footer__list-link">Пожаротушениние</a></li>
                </ul>
            </div>

            <div class="footer__nav-box">
                <ul class="footer__list footer__nav-menu">
                    <li class="footer__nav-item"><a href="#" class="h5 footer__nav-link">Портфолио</a></li>
                    <li class="footer__nav-item"><a href="#" class="h5 footer__nav-link">Контакты</a></li>
                    <li class="footer__nav-item"><a href="#" class="h5 footer__nav-link">Документация</a></li>
                    <li class="footer__nav-item"><a href="#" class="h5 footer__nav-link">Обратный звонок</a></li>
                </ul>
            </div>


        </div>

        <div class="footer__offer-box">
            <div class="footer__offer-text">
                <p class="footer__p_one">Информация, размещенная на сайте, не является публичной офертой. Вы можете
                    использовать для публикаций информацию с сайта <a href="vtis-kirov.ru">vtis-kirov.ru</a> при условии
                    ссылки на источник информации. </p>
                <p class="footer__p_two">Представители СМИ могут получить фото-/видеоматериалы в оригинальном разрешении
                    по запросу на электронный адрес <a href="mailto:sale@vtis-kirov.ru">sale@vtis-kirov.ru</a></p>
            </div>
            <div class="footer__made-in">
                Разработано студией <img src="img/logo_lemonads.svg" alt="">
            </div>
        </div>

    </div>
</footer>
<!-- /.footer -->

<div class="popup__overlay">
    <div class="popup__order-box">
        <div class="h2 popup__order-title">Заявка на обратный звонок</div>
        <div class="popup__order-text p">Оставьте свои контактные данные и мы свяжемся с вами.</div>
        <form action="#" class="popup__order-form">
            <label class="popup__order-label h5" for="name">Ваше имя</label>
            <input class="btn-form popup__order-input btn_br-24" type="text" name="name" id="" required
                placeholder="Владислав">

            <label class="popup__order-label h5" for="phone">Телефон</label>
            <input class="btn-form popup__order-input btn_br-24" type="tel" name="phone" id="" required
                placeholder="+7">

            <!-- <label class="popup__order-label h5" for="description">Описание</label>
                <input class="btn popup__order-input btn_br-24" type="text" name="description" id="" required>
    
                <input class="btn popup__order-files btn_br-24" type="file" name="files" id="files">
                <label class="btn btn_br-24 label-files " for="files">Добавить фото</label> -->
            <!-- <button class="btn btn-hero btn-form-submit" type="submit">отправить<img src="img/arrow-down.png" alt=""></button> -->
            <button class="btn btn-callback btn-order btn-form-submit" type="submit">отправить</button>
            <button class="popup-form-btn-close">X</button>
        </form>
    </div>
</div>
<!-- /.popup__overlay -->


<!-- Подключение Jquery -->
<script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
<!-- owl -->
<script src="js/owl.carousel.min.js"></script>
<script src="js/script.js"></script>
<script>
    window.addEventListener('DOMContentLoaded', function () {
        // owl carusel
        const sliderInfo = $('.owl-carousel');
        sliderInfo.owlCarousel($.extend({}, {
            autoHeight: true,
            items: 1

        }));

        const next = document.querySelector('.arrow-next');
        next.addEventListener('click', function () {
            sliderInfo.trigger('next.owl.carousel')
        });
        var i = 1;
        $('.owl-dot').each(function () {
            $(this).find('span').html(i);
            i++;
        });

    });
</script>
</body>

</html>