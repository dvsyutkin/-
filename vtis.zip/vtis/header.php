<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Вяттехинвестстрой</title>
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/style.min.css">
</head>

<body>

    <header class="header">
        <div class="container">
            <div class="header__wrap">
                <div class="header__logo">
                    <a href="index.php"><img src="img/logo.png" alt="Cook Time"></a>
                </div>


                <div class="nav__wrap">
                    <nav class="nav">

                        <div class="nav__menu hide">
                            <ul class="nav__menu-list">
                                <li class="nav__menu-item"><a href="#">О компании</a></li>

                                <li class="nav__menu-item more">
                                    <a href="#">Услуги<span>&lsaquo;</span></a>
                                    <ul class="mob__menu-more">
                                        <li class="menu__item-more"><a href="#">Trade-in</a></li>
                                        <li class="menu__item-more"><a href="#">Сервисное обслуживание</a></li>
                                        <li class="menu__item-more"><a href="#">Выкуп оборудования</a></li>
                                    </ul>
                                </li>

                                <li class="nav__menu-item more">
                                    <a href="#">Портфолио<span>&lsaquo;</span></a>
                                    <ul class="mob__menu-more">
                                        <li class="menu__item-more"><a href="#">Архитектурное брендирование</a></li>
                                        <li class="menu__item-more"><a href="#">Архитектурные сооружения</a></li>
                                        <li class="menu__item-more"><a href="#">Интерьеры</a></li>
                                        <li class="menu__item-more"><a href="#">Ижс и ландшафтный дизайн</a></li>
                                    </ul>
                                </li>

                                <li class="nav__menu-item"><a href="#">Контакты</a></li>
                            </ul>
                        </div>

                        <button class="btn__menu">
                            <span class="line-menu line-1"></span>
                            <span class="line-menu line-2"></span>
                            <span class="line-menu line-3"></span>
                        </button>

                        <ul class="nav__list">
                            <li class="nav__item"><a href="#">О компании</a></li>

                            <li class="nav__item more-serv">
                                <a class="nav-serv" href="#">Услуги<img src="img/arrow-down.png" alt=""></a>
                                <ul class="dropdown menu__serv">
                                    <li class="menu__serv-item"><a href="" class="menu__serv-link">Trade-in</a></li>
                                    <li class="menu__serv-item"><a href="" class="menu__serv-link">Cервисное обслуживание</a></li>
                                    <li class="menu__serv-item"><a href="" class="menu__serv-link">Выкуп оборудования</a></li>
                                </ul>
                            </li>

                            <li class="nav__item more-portf">
                                <a class="nav-serv" href="portfolio.php">Портфолио<img src="img/arrow-down.png" alt=""></a>
                                <ul class="dropdown menu__portf">
                                    <li class="menu__serv-item"><a href="google.com" class="menu__serv-link">Архитектурное брендирование</a></li>
                                    <li class="menu__serv-item"><a href="" class="menu__serv-link">Архитектурные сооружения</a></li>
                                    <li class="menu__serv-item"><a href="" class="menu__serv-link">Интерьеры</a></li>
                                    <li class="menu__serv-item"><a href="" class="menu__serv-link">Ижс и ландшафтный дизайн</a></li>
                                </ul>
                            </li>
                            <li class="nav__item"><a href="#">Контакты</a></li>
                        </ul>
                    </nav>
                    <button class="btn btn-callback btn-order">Обратный звонок</button>
                </div>
            </div>
        </div>


        <!-- /.container -->

    </header>
    <!-- /.header -->

    
