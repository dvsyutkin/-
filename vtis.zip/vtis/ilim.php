<?php include 'header.php'; ?>
    <main class="main">

        <section class="section hero-ilim">

            <div class="container">

                <div class="hero-ilim__box">
                    <h1 class="h hero__title hero-ilim__title">Илим</h1>
                    <div class="hero-ilim__subtitle p1">
                        Молодом эко-поселке «Васильковые поля» на живописном участке располагается современный
                        двухэтажный коттедж.
                    </div>
                    <div class="hero-ilim__address">
                        <div class="hero__address-box_1">
                            <div class="h4 hero-ilim__address-title">Адрeс</div>
                            <div class="p1 black">ул. Ленини д.116</div>
                        </div>
                        <div class="hero__address-box_2">
                            <div class="h4  hero-ilim__address-title">Общая площадь:</div>
                            <div class="p1 black">301 м2</div>
                        </div>
                    </div>
                </div>

            </div>
            <!-- <button style="display: none;" class="arrow arrow-next"><img src="img/arrow-big.png" alt=""></button> -->

        </section>
        <!-- /.section hero-ilim -->

        <section class="section speciality">
            <div class="container">
                <div class="h2 speciality__title">Особенности</div>
                <div class="speciality__text-wrap">
                    <div class="speciality__text-box">
                        <p class="p1 speciality__text">Современную архитектуру подчеркивают материалы европейского качества – керамический кирпич, клинкерная плитка RECKE и террасная доска Dortmax.</p>
                        <p class="p1 speciality__text">Максимально продуманное планировочное решение дома обеспечивает комфортное проживание. </p>
                    </div>
                    <div class="speciality__text-box">
                        <p class="p1 speciality__text">Где расположены две спальни, санузел и холл с выходом на эксплуатируемую кровлю.</p>
                        <p class="p1 speciality__text">Современный двор с уникальными элементами ландшафтного дизайна, который отлично вписывается в общее стилевое решение и является продолжением дома.</p>
                    </div>
                </div>
            </div>
        </section>
        <!-- /.section speciality -->

        <section class="ilim__slider">
            <div class="owl-carousel">
                <div class="ilim__slider-item">
                    <a href="#" class="ilim__slider-link"><img src="img/ilim/ilim-slider-1.jpg" alt=""></a>
                </div>
                <div class="ilim__slider-item">
                    <a href="#" class="ilim__slider-link"><img src="img/ilim/ilim-slider-2.jpg" alt=""></a>
                </div>
                <div class="ilim__slider-item">
                    <a href="#" class="ilim__slider-link"><img src="img/ilim/ilim-slider-3.jpg" alt=""></a>
                </div>
            </div>
        </section>
        <!-- /.ilim__slider -->

        <section class="section speciality">
            <div class="container">
                <div class="h2 speciality__title">Детали</div>
                <div class="speciality__text-wrap">
                    <div class="speciality__text-box">
                        <p class="p1 speciality__text">Дом выполнен из экологически чистого керамического блока Porotherm с комбинированной отделкой из белого натурального песчаника привезенного из Дагестана и клинкерной плитки Recke графитового оттенка с применением системы остекления из алюминиевых профилей Schuco.
                        </p>
                        <p class="p1 speciality__text">Внутренние помещения коттеджа просторны и комфортны для жизни. На первом этаже находятся просторная кухня-столовая с выходом на террасу, сердцем которой является зона барбекю, зона отдыха с большим бассейном, сауной и хамамом, рабочий кабинет, гостевая комната, гараж на два автомобиля, холл, гардероб, санузел и лестница.</p>
                    </div>
                    <div class="speciality__text-box">
                        <p class="p1 speciality__text">На втором этаже расположены три спальни, одна из которых имеет собственный санузел, гардероб, ванная комната и холл с выходом на эксплуатируемую кровлю. В коттедже предусмотрено просторное подвальное помещение с тренажерным залом, домашним кинотеатром и бильярдной.
                        </p>
                        <p class="p1 speciality__text">
                            Поблизости нет промышленных зон и шумных трасс – здесь царит атмосфера приватности и гармонии с природой. При этом в нескольких минутах ходьбы расположена вся необходимая инфраструктура.</p>
                    </div>
                </div>
            </div>
        </section>
        <!-- /.section speciality 2-->

        <div class="ilim__photo">
            <div class="ilim__photo-wrap">
                <div class="ilim__photo-box">
                    <a href="#" class="ilim__photo-link"><img src="img/ilim/photo-1.jpg" alt="" class="ilim__photo-img"></a>
                    <a href="#" class="ilim__photo-link"><img src="img/ilim/photo-2.jpg" alt="" class="ilim__photo-img"></a>
                    <a href="#" class="ilim__photo-link"><img src="img/ilim/photo-3.jpg" alt="" class="ilim__photo-img"></a>
                </div>
                <div class="ilim__photo-box">
                    <a href="#" class="ilim__photo-link"><img src="img/ilim/photo-4.jpg" alt="" class="ilim__photo-img"></a>
                    <div></div>
                    <a href="#" class="ilim__photo-link"><img src="img/ilim/photo-5.jpg" alt="" class="ilim__photo-img"></a>
                </div>
                <div class="ilim__photo-box">
                    <a href="#" class="ilim__photo-link"><img src="img/ilim/photo-6.jpg" alt="" class="ilim__photo-img"></a>
                    <a href="#" class="ilim__photo-link"><img src="img/ilim/photo-7.jpg" alt="" class="ilim__photo-img"></a>
                    <a href="#" class="ilim__photo-link"><img src="img/ilim/photo-8.jpg" alt="" class="ilim__photo-img"></a>
                </div>
            </div>
        </div>
        <!-- /.ilim__photo -->

        <section class="callback">
            <div class="h2 callback__title">Отзывы о нашей работе</div>
            <div class="callback__wrap">
                <div class="callback__avatar"></div>
                <div class="callback__box">
                    <div class="h3 callback__name">Сергей Евренко</div>
                    <div class="p1 callback__text">Притеррасная низменность, а там действительно могли быть видны звезды, о чем свидетельствует Фукидид дает аргумент перигелия. Проникновение глубинных магм залегает в эстуарий.</div>
                </div>
            </div>
        </section>
        <!-- /.callback -->

        <div class="example">
            <div class="example__wrap">
                <div class="example__box example__box-1">
                    <div class="h3 example__title">Муром</div>
                    <div class="p1 example__desc">Притеррасная низменность, а там действительно могли быть видны звезды, о чем свидетельствует Фукидид дает аргумент перигелия. Проникновение глубинных магм залегает в эстуарий.</div>
                    <div class="example__btn">
                        <button class="btn btn-white btn-hero btn-example">Подробнее о проекте<img src="img/arrow-down.png" alt=""></button>
                    </div>
                </div>
                <div class="example__box example__box-2">
                    <div class="h3 example__title">Красный Якорь</div>
                    <div class="p1 example__desc">Притеррасная низменность, а там действительно могли быть видны звезды, о чем свидетельствует Фукидид дает аргумент перигелия. Проникновение глубинных магм залегает в эстуарий.</div>
                    <div class="example__btn">
                        <button class="btn btn-white btn-hero btn-example">Подробнее о проекте<img src="img/arrow-down.png" alt=""></button>
                    </div>
                </div>

            </div>
        </div>

    </main>
    <!-- /.main -->
    <script >
        window.addEventListener('DOMContentLoaded', function() {
            $('.ilim__slider .owl-carousel').owlCarousel({
                items: 1.5,
                loop: true,
                margin: 20,
                center: true,
                responsive : {
                    600 : {
                        items: 2.5
                    }
                }
                
            });
            
            
        });
    </script>

 <?php include 'footer.php'; ?>